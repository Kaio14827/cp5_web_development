import Footer from './Footer';
import Formulario from './Formulario';
import './App.css';

function App() {
  return (
    <div className="App">
        <Formulario/>
        <Footer/>
    </div>
  );
}

export default App;
