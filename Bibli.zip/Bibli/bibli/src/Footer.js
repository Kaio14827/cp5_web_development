import {FaFacebook, FaInstagram, FaLinkedin, FaTwitter, FaMailBulk, FaPhone, FaShareAlt} from 'react-icons/fa'

import './Footer.css'

function Footer() {
    return (
    <div className='footer'>
        <div className='info'>
        <li>
            <FaMailBulk/>
        </li>
        <h2>Email</h2>
        <p>Você pode nos contatar pelo email: <span>contato@exemplo.com</span></p>
        </div>
        <div className='cell'>
        <li>
            <FaPhone/>
        </li>
        <h2>Telefone</h2>
        <p>Telefone: <span>(11) 98765-4321</span></p>
        </div>
        <div className='redes'>
            <li>
                <FaShareAlt/>
            </li>
            <h2>Redes Sociais:</h2>
            <p>Nos siga nas redes sociais:</p>
        </div>
        <ul className='social_list'>
            <li>
                <FaFacebook/>
            </li>
            <li>
                <FaInstagram/>
            </li>
            <li>
                <FaLinkedin/>
            </li>
            <li>
                <FaTwitter/>
            </li>
        </ul>
        <p className='copy_right'>
            <span>Checkpoint</span> 2024
        </p>
    </div>
    )
}

export default Footer